const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const fs = require('fs');
const sendSms = require('./send_sms');

require('dotenv').config()

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const routes = require('./routes/routes.js')(app, fs);

sendSms(process.env.FROM_NUMBER, process.env.SAMEER_NUMBER , process.env.LINK);

const server = app.listen(3001, () => {
    console.log('listening on port %s...', server.address().port);
}); 