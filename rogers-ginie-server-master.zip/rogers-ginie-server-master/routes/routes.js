// import other routes
const userRoutes = require('./users');
const deviceRoutes = require('./devices');
const storeInfoRoutes = require('./store_info');

const appRouter = (app, fs) => {

    // default route
    app.get('/', (req, res) => {
        res.send('welcome to the development api-server');
    });

    // // other routes
    userRoutes(app, fs);
    deviceRoutes(app, fs);
    storeInfoRoutes(app, fs);

};

module.exports = appRouter;