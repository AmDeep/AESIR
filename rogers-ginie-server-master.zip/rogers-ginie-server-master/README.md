# rogers-genie-server
# an application that monitors a customer's devices and prompts for sending tech assistance to customer

