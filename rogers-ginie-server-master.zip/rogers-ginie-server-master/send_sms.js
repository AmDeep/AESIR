// Send sms to client

const sendSms = (from_mobile_number, to_mobile_number, link = 'https://www.rogers.com') => {
  const accountSid = process.env.ACCOUNT_SID;
  const authToken = process.env.AUTH_TOKEN;
  const client = require('twilio')(accountSid, authToken);
  const message_body = `We noticed something went wrong with your internet. \n
                        Would you like to schedule for Tech Help? \n
                        Please click this link to schedule: ${link} `

  
  // client.messages
  //   .create({
  //      body: message_body,
  //      from: from_mobile_number,
  //      to: to_mobile_number
  //    })
  //   .then(message => console.log(message.sid));

    console.log(`message sent to ${to_mobile_number} from ${from_mobile_number}.
                message: ${message_body}`)

}

module.exports = sendSms;